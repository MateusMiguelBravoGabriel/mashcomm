# 🛠️ MeshComm — Instruções de Compilação

> Guia passo a passo para compilar o MeshComm em APK Android e iOS.

---

## 📋 PRÉ-REQUISITOS

### Para Android

| Ferramenta | Versão Mínima | Download |
|------------|---------------|----------|
| **Node.js** | 18.x LTS | https://nodejs.org |
| **Android Studio** | Hedgehog (2023.1.1) | https://developer.android.com/studio |
| **JDK** | 17 | Incluído no Android Studio |
| **Android SDK** | API 34 | Via Android Studio SDK Manager |
| **Git** | 2.x | https://git-scm.com |

### Para iOS

| Ferramenta | Versão Mínima | Download |
|------------|---------------|----------|
| **macOS** | 13+ (Ventura) | — |
| **Xcode** | 15+ | Mac App Store |
| **Node.js** | 18.x LTS | https://nodejs.org |
| **CocoaPods** | 1.12+ | `sudo gem install cocoapods` |

---

## 🤖 ANDROID — Compilação

### Passo 1: Instalar Dependências

```bash
# Navegar para a pasta do projeto
cd meshcomm-project

# Instalar dependências Node.js
npm install

# Sincronizar Capacitor com Android
npx cap sync android
```

### Passo 2: Configurar Android Studio

```bash
# Abrir projeto no Android Studio
npx cap open android
```

No Android Studio:
1. **Sync Project with Gradle Files** (elefante na toolbar)
2. **Build → Make Project** (Ctrl+F9)
3. Verificar se não há erros de compilação

### Passo 3: Configurar Permissões (já feito no AndroidManifest.xml)

As permissões já estão configuradas em `android/app/src/main/AndroidManifest.xml`:
- Bluetooth LE (scan, advertise, connect)
- Wi-Fi Direct
- Localização (para BLE scan)
- Armazenamento
- Câmara
- Notificações

### Passo 4: Compilar APK Debug

```bash
# Via Android Studio:
# Build → Build Bundle(s) / APK(s) → Build APK(s)

# Ou via terminal:
cd android
./gradlew assembleDebug
```

**APK gerado em:** `android/app/build/outputs/apk/debug/app-debug.apk`

### Passo 5: Instalar no Telemóvel

```bash
# Via ADB
adb install android/app/build/outputs/apk/debug/app-debug.apk

# Ou arrastar APK para o emulador Android Studio
```

### Passo 6: Compilar APK Release (Assinado)

```bash
# 1. Gerar keystore (só uma vez)
keytool -genkey -v   -keystore meshcomm.keystore   -alias meshcomm   -keyalg RSA   -keysize 2048   -validity 10000

# 2. Guardar keystore em android/app/meshcomm.keystore
# 3. Configurar signing em android/app/build.gradle (já feito)

# 4. Compilar release
cd android
./gradlew assembleRelease

# APK assinado em:
# android/app/build/outputs/apk/release/app-release.apk
```

---

## 🍎 iOS — Compilação

### Passo 1: Instalar Dependências

```bash
# Navegar para a pasta do projeto
cd meshcomm-project

# Instalar dependências Node.js
npm install

# Sincronizar Capacitor com iOS
npx cap sync ios

# Instalar pods (dependências iOS)
cd ios/App
pod install
cd ../..
```

### Passo 2: Configurar Xcode

```bash
# Abrir projeto no Xcode
npx cap open ios
```

No Xcode:
1. Selecionar **target "App"**
2. Em **Signing & Capabilities**, adicionar:
   - **Bluetooth** (Background Modes → Uses Bluetooth LE accessories)
   - **Wi-Fi** (Access WiFi Information)
   - **Push Notifications** (opcional)
3. Selecionar **Team** (Apple Developer account)
4. Definir **Bundle Identifier**: `com.meshcomm.app`

### Passo 3: Compilar e Correr

```bash
# Via Xcode: Cmd+R

# Ou via terminal:
npx cap run ios --target="iPhone 15 Pro"
```

---

## 🔄 FLUXO DE DESENVOLVIMENTO

### Ciclo de Desenvolvimento Rápido

```bash
# 1. Editar código web (www/)
vim www/index.html

# 2. Sincronizar mudanças para nativo
npx cap sync

# 3. Correr no dispositivo
npx cap run android
npx cap run ios

# 4. Para live reload (desenvolvimento web)
npx cap run android --livereload --external
```

### Estrutura de Edição

| Ficheiro | Onde editar | Sincroniza para |
|----------|-------------|-----------------|
| UI Web | `www/index.html` | `android/app/src/main/assets/public/` |
| Plugin Bridge | `android/app/src/main/java/com/meshcomm/app/MeshCommPlugin.kt` | — (não precisa sync) |
| Criptografia | `android/app/src/main/java/com/meshcomm/app/CryptoEngine.kt` | — (não precisa sync) |
| Config Android | `android/app/build.gradle` | — (rebuild no Android Studio) |

---

## 🐛 DEBUG

### Android

```bash
# Ver logs
adb logcat -s MeshComm:D

# Debug via Android Studio
# Run → Debug 'app'

# Inspecionar WebView
# chrome://inspect no Chrome desktop
```

### iOS

```bash
# Ver logs
# Xcode → Window → Devices and Simulators → Console

# Debug Safari WebView
# Safari → Develop → [dispositivo] → index.html
```

---

## 📦 PUBLICAÇÃO

### Google Play Store

1. Criar conta de developer ($25 uma vez)
2. Gerar AAB (Android App Bundle):
   ```bash
   cd android
   ./gradlew bundleRelease
   ```
3. Upload em https://play.google.com/console

### Apple App Store

1. Criar conta de developer ($99/ano)
2. Arquivar no Xcode: Product → Archive
3. Upload via Organizer → Distribute App
4. Submeter para review (3-7 dias)

---

## ⚡ COMANDOS RÁPIDOS

```bash
# Setup completo (primeira vez)
npm install && npx cap sync

# Correr em Android
npx cap run android

# Correr em iOS
npx cap run ios

# Compilar APK debug
cd android && ./gradlew assembleDebug

# Compilar APK release
cd android && ./gradlew assembleRelease

# Live reload (desenvolvimento)
npx cap run android --livereload

# Limpar e rebuild
cd android && ./gradlew clean && cd .. && npx cap sync
```

---

## 🆘 TROUBLESHOOTING

| Erro | Solução |
|------|---------|
| `Gradle sync failed` | File → Invalidate Caches → Restart |
| `BLUETOOTH_SCAN permission denied` | Verificar AndroidManifest.xml + runtime permissions |
| `SQLCipher native library not found` | Adicionar `android:extractNativeLibs="true"` no manifest |
| `Capacitor bridge not found` | Correr `npx cap sync` novamente |
| `iOS build failed` | `pod deintegrate && pod install` |
| `WebRTC not linking` | Verificar arquiteturas (arm64, x86_64) |

---

**MeshComm v1.0.0 — Documentação de Compilação**
