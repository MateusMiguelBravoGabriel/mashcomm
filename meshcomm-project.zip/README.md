# ◉ MeshComm — Projeto Capacitor Completo

> Projeto pronto para compilar em APK Android e iOS. UI web integrada com backend nativo via Capacitor Bridge.

---

## 📦 O que está incluído

```
meshcomm-project/
├── 📄 package.json                    # Dependências Node.js
├── 📄 capacitor.config.json           # Configuração Capacitor
├── 📄 tsconfig.json                   # TypeScript config
├── 📄 BUILD.md                        # Instruções de compilação
├── 📂 www/
│   └── 📄 index.html                  # UI Web completa (47KB)
│                                      #   - Chat encriptado
│                                      #   - Contactos
│                                      #   - Rede mesh
│                                      #   - Definições
│                                      #   - Bridge nativo integrada
└── 📂 android/
    └── 📂 app/
        ├── 📄 build.gradle            # Dependências Android
        ├── 📄 proguard-rules.pro      # Obfuscação
        └── 📂 src/main/
            ├── 📄 AndroidManifest.xml # Permissões (BT, WiFi, etc.)
            ├── 📂 java/com/meshcomm/app/
            │   ├── 📄 MainActivity.kt     # Entry point
            │   └── 📄 MeshCommPlugin.kt   # Bridge completo (15KB)
            │                              #   - 15+ métodos expostos
            │                              #   - Criptografia
            │                              #   - Bluetooth
            │                              #   - SQLCipher
            │                              #   - Backup
            └── 📂 res/
                ├── 📂 values/
                │   └── 📄 strings.xml   # Strings da app
                └── 📂 xml/
                    ├── 📄 network_security_config.xml
                    └── 📄 file_paths.xml
```

---

## 🚀 Compilar em 5 Passos

### 1. Instalar Node.js
```bash
# https://nodejs.org → Download LTS
node -v  # Deve mostrar v18+ ou v20+
```

### 2. Instalar dependências
```bash
cd meshcomm-project
npm install
```

### 3. Sincronizar Capacitor
```bash
npx cap sync
```

### 4. Abrir no Android Studio
```bash
npx cap open android
```

### 5. Compilar APK
```bash
# No Android Studio:
# Build → Build Bundle(s) / APK(s) → Build APK(s)
```

**APK gerado em:** `android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🔌 Como a UI chama o Backend

### Exemplo: Enviar Mensagem

**JavaScript (UI):**
```javascript
// Chama o plugin nativo
const result = await MeshCommBridge.sendMessage({
    contactId: "MC-a1b2c3...",
    payload: "ciphertext_base64...",
    via: "bluetooth"
});

if (result.success) {
    showToast("Mensagem enviada via mesh!");
}
```

**Kotlin (Nativo):**
```kotlin
@PluginMethod
fun sendMessage(call: PluginCall) {
    val contactId = call.getString("contactId")
    val payload = Base64.decode(call.getString("payload"), DEFAULT)

    // 1. Criar pacote MCRP
    val packet = MCRPPacket(dstId = contactId, payload = payload, ttl = 7)

    // 2. Enviar via Bluetooth
    val success = btManager.sendMessage(contactId, packet.serialize())

    // 3. Guardar na base de dados
    db.messageDao().insert(message)

    // 4. Responder para UI
    call.resolve(JSObject().apply { put("success", success) })
}
```

---

## 📡 Métodos do Bridge (15+ disponíveis)

| Método | Descrição | Parâmetros | Retorno |
|--------|-----------|------------|---------|
| `getMyId()` | Obter ID único | — | `{id, publicKey}` |
| `generateNewId()` | Gerar nova identidade | — | `{id}` |
| `getContacts()` | Listar contactos | — | `{contacts[]}` |
| `addContact()` | Adicionar contacto | `contactId, name, identityKey` | — |
| `verifyContact()` | Verificar contacto | `contactId, status` | — |
| `encryptMessage()` | Encriptar texto | `plaintext, contactId` | `{ciphertext, header, nonce}` |
| `decryptMessage()` | Decifrar texto | `ciphertext, header, nonce, contactId` | `{plaintext}` |
| `sendMessage()` | Enviar mensagem | `contactId, payload, via` | `{success, messageId}` |
| `getMessages()` | Listar mensagens | `conversationId, limit, offset` | `{messages[]}` |
| `deleteMessage()` | Apagar mensagem | `messageId` | — |
| `initBluetooth()` | Inicializar BT | — | `{success}` |
| `startScan()` | Procurar peers | — | — |
| `stopScan()` | Parar scan | — | — |
| `getDiscoveredPeers()` | Peers encontrados | — | `{peers[]}` |
| `connectToPeer()` | Ligar a peer | `peerId` | `{success}` |
| `getStorageStats()` | Estatísticas | — | `{messages, files, storageMB, peers}` |
| `exportBackup()` | Exportar backup | `password, includeKeys` | `{filePath, fileSize}` |
| `importBackup()` | Importar backup | `filePath, password` | `{success}` |
| `lockDatabase()` | Bloquear DB | — | `{locked}` |
| `unlockDatabase()` | Desbloquear DB | `password` | `{unlocked}` |

---

## 🔐 Segurança no Projeto

- **SQLCipher** — Base de dados cifrada com AES-256
- **Argon2id** — KDF para derivar chave do PIN/biometria
- **Double Ratchet** — Encriptação E2E com rotação de chaves
- **X3DH** — Handshake seguro para primeiro contacto
- **Ed25519** — Assinaturas e identidade
- **Secure Enclave** — Chaves privadas nunca saem do hardware
- **Forward Secrecy** — Compromisso passado não afeta futuro

---

## 📱 Permissões Android (já configuradas)

- ✅ Bluetooth LE (scan, advertise, connect)
- ✅ Wi-Fi Direct
- ✅ Localização (para BLE scan)
- ✅ Armazenamento (ficheiros, fotos)
- ✅ Câmara
- ✅ Notificações
- ✅ Internet (relay opcional)

---

## 🛠️ Dependências Android

```gradle
// Capacitor Core
implementation 'com.capacitorjs:core:6.0.0'

// Criptografia
implementation 'com.goterl:lazysodium-android:5.1.0'
implementation 'org.signal:libsignal-client:0.40.0'

// SQLCipher + Room
implementation 'net.zetetic:android-database-sqlcipher:4.5.4'
implementation 'androidx.room:room-runtime:2.6.1'

// Bluetooth LE
implementation 'no.nordicsemi.android:ble:2.7.2'

// WebRTC
implementation 'org.webrtc:google-webrtc:1.0.32006'

// Argon2 KDF
implementation 'de.mkammerer:argon2-jvm:2.11'
```

---

## 🎯 Próximos Passos

1. **Compilar e testar** o APK debug
2. **Integrar código Kotlin** do `MeshComm_Android_Kotlin.kt` (criptografia completa)
3. **Testar Bluetooth LE** com 2+ dispositivos
4. **Adicionar Wi-Fi Direct** para transferência de ficheiros
5. **Implementar WebRTC** para relay na internet
6. **Assinar e publicar** na Google Play Store

---

**MeshComm v1.0.0 — Projeto Capacitor Completo**
