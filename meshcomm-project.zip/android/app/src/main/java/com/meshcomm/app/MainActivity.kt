package com.meshcomm.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(MeshCommPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
