package com.meshcomm.app

import android.util.Base64
import com.getcapacitor.*
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.PluginMethod
import org.json.JSONArray
import org.json.JSONObject

/**
 * MeshCommPlugin — Bridge entre UI Web (Capacitor) e Backend Nativo (Kotlin)
 * 
 * Este plugin expõe métodos que a UI JavaScript pode chamar para:
 * - Gerar/obter ID único
 * - Encriptar mensagens (Double Ratchet)
 * - Enviar mensagens via Bluetooth/WiFi
 * - Gerir contactos
 * - Guardar/carregar dados do SQLCipher
 */
@CapacitorPlugin(name = "MeshCommBridge")
class MeshCommPlugin : Plugin() {

    private lateinit var cryptoEngine: CryptoEngine
    private lateinit var btManager: BluetoothMeshManager
    private lateinit var db: MeshDatabase
    private lateinit var routingEngine: MeshRoutingEngine

    override fun load() {
        super.load()

        // Inicializar componentes nativos
        cryptoEngine = CryptoEngine()
        btManager = BluetoothMeshManager(context)
        db = DatabaseHelper.createEncryptedDatabase(context, getDatabasePassword())
        routingEngine = MeshRoutingEngine(db)

        // Inicializar identidade
        IdentityManager.initialize(context)

        // Iniciar Bluetooth
        btManager.start()

        // Escutar mensagens recebidas e notificar UI
        btManager.setOnMessageReceivedListener { packet, fromPeer ->
            routingEngine.processIncomingPacket(packet, fromPeer)
            notifyUIMessageReceived(packet)
        }
    }

    // ===================== IDENTITY =====================

    @PluginMethod
    fun getMyId(call: PluginCall) {
        val ret = JSObject()
        ret.put("id", IdentityManager.getMyId())
        ret.put("publicKey", Base64.encodeToString(IdentityManager.getIdentityKeyPair().public, Base64.DEFAULT))
        call.resolve(ret)
    }

    @PluginMethod
    fun generateNewId(call: PluginCall) {
        IdentityManager.regenerate()
        val ret = JSObject()
        ret.put("id", IdentityManager.getMyId())
        call.resolve(ret)
    }

    // ===================== CONTACTS =====================

    @PluginMethod
    fun getContacts(call: PluginCall) {
        val contacts = db.contactDao().getAll()
        val arr = JSArray()

        contacts.forEach { contact ->
            val obj = JSObject()
            obj.put("id", contact.contactId.toHex())
            obj.put("name", contact.displayName)
            obj.put("verified", contact.verifiedStatus)
            obj.put("lastSeen", contact.lastSeenAt ?: 0)
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("contacts", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun addContact(call: PluginCall) {
        val contactId = call.getString("contactId") ?: return call.reject("Missing contactId")
        val name = call.getString("name") ?: "Unknown"
        val identityKey = call.getString("identityKey") ?: return call.reject("Missing identityKey")

        db.contactDao().insert(ContactEntity(
            contactId = contactId.hexToBytes(),
            displayName = name,
            identityKey = Base64.decode(identityKey, Base64.DEFAULT),
            verifiedStatus = 0,
            addedAt = System.currentTimeMillis()
        ))

        call.resolve()
    }

    @PluginMethod
    fun verifyContact(call: PluginCall) {
        val contactId = call.getString("contactId") ?: return call.reject("Missing contactId")
        val status = call.getInt("status") ?: 1

        db.contactDao().updateVerifiedStatus(contactId.hexToBytes(), status)
        call.resolve()
    }

    // ===================== MESSAGING =====================

    @PluginMethod
    fun encryptMessage(call: PluginCall) {
        val plaintext = call.getString("plaintext") ?: return call.reject("Missing plaintext")
        val contactId = call.getString("contactId") ?: return call.reject("Missing contactId")

        val contact = db.contactDao().getById(contactId.hexToBytes())
            ?: return call.reject("Contact not found")

        // Restaurar Double Ratchet
        val ratchet = restoreRatchet(contact)

        // Encriptar
        val encrypted = ratchet.encrypt(
            plaintext.toByteArray(Charsets.UTF_8),
            contactId.hexToBytes()
        )

        // Guardar estado atualizado
        saveRatchetState(contactId.hexToBytes(), ratchet)

        val ret = JSObject()
        ret.put("ciphertext", Base64.encodeToString(encrypted.ciphertext, Base64.DEFAULT))
        ret.put("header", Base64.encodeToString(encrypted.header.serialize(), Base64.DEFAULT))
        ret.put("nonce", Base64.encodeToString(encrypted.nonce, Base64.DEFAULT))
        call.resolve(ret)
    }

    @PluginMethod
    fun decryptMessage(call: PluginCall) {
        val ciphertext = call.getString("ciphertext") ?: return call.reject("Missing ciphertext")
        val header = call.getString("header") ?: return call.reject("Missing header")
        val nonce = call.getString("nonce") ?: return call.reject("Missing nonce")
        val contactId = call.getString("contactId") ?: return call.reject("Missing contactId")

        val contact = db.contactDao().getById(contactId.hexToBytes())
            ?: return call.reject("Contact not found")

        val ratchet = restoreRatchet(contact)

        val message = RatchetMessage(
            header = RatchetHeader.deserialize(Base64.decode(header, Base64.DEFAULT)),
            ciphertext = Base64.decode(ciphertext, Base64.DEFAULT),
            nonce = Base64.decode(nonce, Base64.DEFAULT)
        )

        val plaintext = ratchet.decrypt(message, contactId.hexToBytes())
            ?: return call.reject("Decryption failed")

        saveRatchetState(contactId.hexToBytes(), ratchet)

        val ret = JSObject()
        ret.put("plaintext", String(plaintext, Charsets.UTF_8))
        call.resolve(ret)
    }

    @PluginMethod
    fun sendMessage(call: PluginCall) {
        val contactId = call.getString("contactId") ?: return call.reject("Missing contactId")
        val payload = call.getString("payload") ?: return call.reject("Missing payload")
        val via = call.getString("via") ?: "bluetooth"

        val payloadBytes = Base64.decode(payload, Base64.DEFAULT)

        // Criar pacote MCRP
        val packet = MCRPPacket(
            type = MCRP_TYPE_DATA,
            dstId = contactId.hexToBytes(),
            srcId = IdentityManager.getMyIdBytes(),
            ttl = 7,
            payload = payloadBytes,
            msgId = CryptoEngine.blake3Hash(payloadBytes + System.currentTimeMillis().toString().toByteArray())
        )

        // Enviar via interface selecionada
        val success = when(via) {
            "bluetooth" -> btManager.sendMessage(contactId, packet.serialize())
            "wifi" -> WifiDirectManager.send(contactId, packet.serialize())
            "internet" -> WebRTCManager.send(contactId, packet.serialize())
            else -> btManager.sendMessage(contactId, packet.serialize())
        }

        // Guardar na base de dados
        if (success) {
            db.messageDao().insert(MessageEntity(
                messageId = packet.msgId,
                conversationId = contactId.hexToBytes(),
                senderId = IdentityManager.getMyIdBytes(),
                messageType = "text",
                ciphertext = payloadBytes,
                ratchetHeader = ByteArray(0),
                nonce = ByteArray(0),
                timestampSent = System.currentTimeMillis(),
                status = "sent",
                isOutgoing = true,
                receivedVia = via
            ))
        }

        val ret = JSObject()
        ret.put("success", success)
        ret.put("messageId", packet.msgId.toHex())
        ret.put("via", via)
        call.resolve(ret)
    }

    @PluginMethod
    fun getMessages(call: PluginCall) {
        val conversationId = call.getString("conversationId") ?: return call.reject("Missing conversationId")
        val limit = call.getInt("limit") ?: 100
        val offset = call.getInt("offset") ?: 0

        val messages = db.messageDao().getByConversation(
            conversationId.hexToBytes(),
            limit,
            offset
        )

        val arr = JSArray()
        messages.forEach { msg ->
            val obj = JSObject()
            obj.put("messageId", msg.messageId.toHex())
            obj.put("senderId", msg.senderId.toHex())
            obj.put("type", msg.messageType)
            obj.put("ciphertext", Base64.encodeToString(msg.ciphertext, Base64.DEFAULT))
            obj.put("timestamp", msg.timestampSent)
            obj.put("status", msg.status)
            obj.put("isOutgoing", msg.isOutgoing)
            obj.put("receivedVia", msg.receivedVia ?: "unknown")
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("messages", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun deleteMessage(call: PluginCall) {
        val messageId = call.getString("messageId") ?: return call.reject("Missing messageId")
        db.messageDao().delete(messageId.hexToBytes())
        call.resolve()
    }

    // ===================== BLUETOOTH =====================

    @PluginMethod
    fun initBluetooth(call: PluginCall) {
        val success = btManager.initialize()
        if (success) {
            btManager.start()
        }
        val ret = JSObject()
        ret.put("success", success)
        call.resolve(ret)
    }

    @PluginMethod
    fun startScan(call: PluginCall) {
        btManager.startScan()
        call.resolve()
    }

    @PluginMethod
    fun stopScan(call: PluginCall) {
        btManager.stopScan()
        call.resolve()
    }

    @PluginMethod
    fun getDiscoveredPeers(call: PluginCall) {
        val peers = btManager.getDiscoveredPeers()
        val arr = JSArray()

        peers.forEach { peer ->
            val obj = JSObject()
            obj.put("id", peer.idHint)
            obj.put("rssi", peer.rssi)
            obj.put("battery", peer.batteryLevel)
            obj.put("interface", peer.interfaceType.name)
            obj.put("lastSeen", peer.lastSeen)
            arr.put(obj)
        }

        val ret = JSObject()
        ret.put("peers", arr)
        call.resolve(ret)
    }

    @PluginMethod
    fun connectToPeer(call: PluginCall) {
        val peerId = call.getString("peerId") ?: return call.reject("Missing peerId")
        val success = btManager.connect(peerId)
        val ret = JSObject()
        ret.put("success", success)
        call.resolve(ret)
    }

    // ===================== STORAGE / STATS =====================

    @PluginMethod
    fun getStorageStats(call: PluginCall) {
        val stats = db.getStorageStats()
        val ret = JSObject()
        ret.put("messages", stats.messageCount)
        ret.put("files", stats.fileCount)
        ret.put("storageMB", stats.storageBytes / (1024.0 * 1024.0))
        ret.put("peers", stats.peerCount)
        call.resolve(ret)
    }

    @PluginMethod
    fun exportBackup(call: PluginCall) {
        val password = call.getString("password") ?: return call.reject("Missing password")
        val includeKeys = call.getBoolean("includeKeys") ?: false

        val backupFile = BackupManager.export(context, db, password, includeKeys)

        val ret = JSObject()
        ret.put("filePath", backupFile.absolutePath)
        ret.put("fileSize", backupFile.length())
        call.resolve(ret)
    }

    @PluginMethod
    fun importBackup(call: PluginCall) {
        val filePath = call.getString("filePath") ?: return call.reject("Missing filePath")
        val password = call.getString("password") ?: return call.reject("Missing password")

        val success = BackupManager.import(context, filePath, password)

        val ret = JSObject()
        ret.put("success", success)
        call.resolve(ret)
    }

    // ===================== SECURITY =====================

    @PluginMethod
    fun lockDatabase(call: PluginCall) {
        db.close()
        val ret = JSObject()
        ret.put("locked", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun unlockDatabase(call: PluginCall) {
        val password = call.getString("password") ?: return call.reject("Missing password")
        db = DatabaseHelper.createEncryptedDatabase(context, password)
        val ret = JSObject()
        ret.put("unlocked", true)
        call.resolve(ret)
    }

    // ===================== PRIVATE HELPERS =====================

    private fun getDatabasePassword(): String {
        // Em produção: derivar do PIN/biometria via Argon2id
        // Por agora: usar chave do Android Keystore
        return KeyStoreManager.getDatabaseKey(context)
    }

    private fun restoreRatchet(contact: ContactEntity): DoubleRatchet {
        val ratchet = DoubleRatchet(contact.rootKey ?: ByteArray(32))
        ratchet.restoreState(
            sendChainKey = contact.sendChainKey,
            recvChainKey = contact.recvChainKey,
            dhPriv = contact.dhPrivKey,
            dhPubRemote = contact.dhPubRemote,
            sendNum = contact.sendMsgNumber,
            recvNum = contact.recvMsgNumber,
            prevChainLen = contact.prevChainLength
        )
        return ratchet
    }

    private fun saveRatchetState(contactId: ByteArray, ratchet: DoubleRatchet) {
        db.contactDao().updateRatchetState(
            contactId,
            ratchet.getRootKey(),
            ratchet.getSendChainKey(),
            ratchet.getRecvChainKey(),
            ratchet.getDhPrivKey(),
            ratchet.getDhPubRemote(),
            ratchet.getSendMsgNum(),
            ratchet.getRecvMsgNum(),
            ratchet.getPrevChainLen()
        )
    }

    private fun notifyUIMessageReceived(packet: MCRPPacket) {
        val data = JSObject()
        data.put("senderId", packet.srcId.toHex())
        data.put("messageId", packet.msgId.toHex())
        data.put("timestamp", System.currentTimeMillis())
        data.put("hopCount", packet.hopCount)

        bridge.triggerWindowJSEvent("meshMessageReceived", data.toString())
    }

    // ===================== CONSTANTS =====================

    companion object {
        const val MCRP_TYPE_DATA = 0x01
        const val MCRP_TYPE_ACK = 0x02
        const val MCRP_TYPE_BEACON = 0x03
        const val MCRP_TYPE_ROUTE_REQ = 0x04
        const val MCRP_TYPE_ROUTE_REP = 0x05
    }
}

// Extension functions
fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }
fun String.hexToBytes(): ByteArray {
    val len = length
    val data = ByteArray(len / 2)
    for (i in 0 until len step 2) {
        data[i / 2] = ((Character.digit(this[i], 16) shl 4) + Character.digit(this[i + 1], 16)).toByte()
    }
    return data
}
