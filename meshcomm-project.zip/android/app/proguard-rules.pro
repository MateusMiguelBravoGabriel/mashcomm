# MeshComm ProGuard Rules
# Criptografia
-keep class com.goterl.** { *; }
-keep class org.signal.** { *; }
-keep class net.sqlcipher.** { *; }

# Room
-keep class androidx.room.** { *; }
-keep class com.meshcomm.app.db.** { *; }

# Capacitor
-keep class com.getcapacitor.** { *; }
-keep class com.meshcomm.app.MeshCommPlugin { *; }

# Sodium
-keep class com.sun.jna.** { *; }
-keep class * implements com.sun.jna.** { *; }

# WebRTC
-keep class org.webrtc.** { *; }

# Geral
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions
-keepattributes InnerClasses
-keepattributes EnclosingMethod
